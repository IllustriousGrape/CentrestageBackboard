import pygame as py
import random
import math
py.init()
screen = py.display.set_mode((450, 670))
running = True
backdrop = [[' ', ' ', ' ', ' ', ' ', ' ',  '9'], [' ', ' ', ' ', ' ', ' ', ' ', ' '],
            [' ', ' ', ' ', ' ', ' ', ' ',  '9'], [' ', ' ', ' ', ' ', ' ', ' ', ' '],
            [' ', ' ', ' ', ' ', ' ', ' ',  '9'], [' ', ' ', ' ', ' ', ' ', ' ', ' '],
            [' ', ' ', ' ', ' ', ' ', ' ',  '9'], [' ', ' ', ' ', ' ', ' ', ' ', ' '],
            [' ', ' ', ' ', ' ', ' ', ' ',  '9'], [' ', ' ', ' ', ' ', ' ', ' ', ' '],
            [' ', ' ', ' ', ' ', ' ', ' ',  '9'], [' ', ' ', ' ', ' ', ' ', ' ', ' ']]

nulled = [[0, 6], [2, 6], [4, 6], [6, 6], [8, 6], [10, 6]]
filled = []
currentHighest = 0
a=0
indexer = []
for i in range(12):
    for j in range(7):
        if backdrop[i][j] != '9':
            indexer.append([a, [i,j]])
            a+=1
def getter(x,y):
    for i in range(len(indexer)):
        if indexer[i][1][0] == x and indexer[i][1][1]  == y:
            return indexer[i][0]
def centerer(colour, x,y):
    py.draw.polygon(screen, colour, [(x, y-28.87), (x-25, y-28.87/2), (x-25, y+28.87/2), (x, y+28.87), (x+25, y+28.87/2), (x+25, y-28.87/2)], 0)




def supported(x, y):
    if [x, y] in nulled:
        return False
    elif [x, y] in filled:
        return False
    elif x == 0:
        return True
    elif backdrop[x][6] == '9':
        if [(x - 1), y] in filled and [(x - 1), (y + 1)] in filled:
            return True
        else:
            return False
    elif y == 0:
        if [x - 1, 0] in filled:
            return True
        else:
            return False
    elif y == 6:
        if [x - 1, 5] in filled:
            return True
        else:
            return False
    else:
        if [(x - 1), (y - 1)] in filled and [(x - 1), y] in filled:
            return True
        else:
            return False

def potential():
    poA = []
    for i in range(currentHighest+2):
        for j in range(7):
            if supported(i,j):
                poA.append([i,j])
    return poA
def formatter(back):
    for i in range(12):
        print(back[11-i])



formatter(backdrop)

bigBoyList = []
for i in range(6):
    k = []
    k.append([0, i+1])
    k.append([1,i])
    k.append([1,i+1])
    k.append([0,i-1])
    bigBoyList.append(k)
count = 5

for i in range(12):
    if i != 0:
        if i % 2 == 1:
            for j in range(7):
                count +=1
                if i!= 10:
                    if j == 0:
                        k = []
                        k.append([i-1, 0])
                        k.append([i,1])
                        k.append([i+1,0])
                        bigBoyList.append(k)
                    elif j==6:
                        k = []
                        k.append([i - 1, 5])
                        k.append([i, 5])
                        k.append([i + 1, 5])
                        bigBoyList.append(k)
                    elif j < 7 and j>0:
                        k=[]
                        k.append([i, j-1])
                        k.append([i, j + 1])
                        k.append([i-1, j-1])
                        k.append([i-1,j])
                        k.append([i+1, j-1])
                        k.append([i+1, j])
                        bigBoyList.append(k)
                else:
                    if j == 0:
                        k = []
                        k.append([i-1, 0])
                        k.append([i,1])
                        bigBoyList.append(k)
                    elif j==6:
                        k = []
                        k.append([i - 1, 5])
                        k.append([i, 5])
                        bigBoyList.append(k)
                    elif j < 6 and j>0:
                        k=[]
                        k.append([i, j-1])
                        k.append([i, j + 1])
                        k.append([i-1, j-1])
                        k.append([i-1,j])
                        bigBoyList.append(k)
        else:
            for j in range(6):
                count +=1
                if j == 0:
                    k = []
                    k.append([i - 1, 0])
                    k.append([i - 1, 1])
                    k.append([i, 1])
                    k.append([i + 1, 0])
                    k.append([i+1, 1])
                    bigBoyList.append(k)
                elif j == 5:
                    k = []
                    k.append([i - 1, 5])
                    k.append([i - 1, 6])
                    k.append([i, 4])
                    k.append([i + 1, 5])
                    k.append([i+1, 6])
                    bigBoyList.append(k)
                elif j < 6 and j > 0:
                    k = []
                    k.append([i, j - 1])
                    k.append([i, j + 1])
                    k.append([i - 1, j  + 1])
                    k.append([i - 1, j])
                    k.append([i + 1, j + 1])
                    k.append([i + 1, j])
                    bigBoyList.append(k)
print("--------------------------------------")





def getbetter(x,y):
    return bigBoyList[getter(x,y)]

def mosaicAnalyser():
    allMosaics = []
    for i in range(currentHighest+1):
        for j in range(7):
            if backdrop[i][j] == '2':

                count = 0
                other =[]
                for l in range(len(getbetter(i,j))):
                    if backdrop[getbetter(i,j)[l][0]][getbetter(i,j)[l][1]] == '2':
                        count +=1
                        other.append([getbetter(i,j)[l][0], getbetter(i,j)[l][1]])
                if count == 2:
                    x = other[0][0]
                    y = other[0][1]
                    count = 0
                    oldx =  other[0][0]
                    oldy = other[0][1]
                    for z in range(len(getbetter(x,y))):
                        if backdrop[getbetter(x,y)[z][0]][getbetter(x,y)[z][1]] == '2':
                            count +=1
                    if count ==2:
                        x = other[1][0]
                        y = other[1][1]
                        z=0
                        count = 0
                        for z in range(len(getbetter(x, y))):
                            if backdrop[getbetter(x, y)[z][0]][getbetter(x, y)[z][1]] == '2':
                                count += 1
                        if count ==2 and [i,j] in getbetter(x, y) and [oldx, oldy] in getbetter(x,y):
                            other.append([i,j])
                            allMosaics.append(other)

    return allMosaics


def mosaicCounter():
    return math.floor(len(mosaicAnalyser())/3)
def currentScore():
    heightScore = math.floor((currentHighest+1)/3)*10
    numberOfPixels = 0
    for i in range(12):
        for j in range(7):
            if backdrop[i][j] == '2' or backdrop[i][j] == '1':
                numberOfPixels+=1
    pixelScore = 3*numberOfPixels + mosaicCounter()*10
    score = heightScore + pixelScore
    return score
position = -7
positionList = []
for i in range(6):
    position += 7
    for j in range(6):
        positionList.append([position, 100+50*(j), 570 - 28.87 - 28.87*(3*i)])
        position+=1
position = 0
for i in range(5):
    position += 6
    for j in range(7):
        positionList.append([position, 75 + 50 * (j), 570 - 2.5*28.87 - 28.87 * (3 * i)])
        position += 1
executables = []

def place(x, y, z, currentHighest):
    if supported(x, y):
        backdrop[x][y] = z
        filled.append([x,y])
        e = getter(x,y)
        for i in range(len(positionList)):
            if positionList[i][0] == e:
                if z == '2':
                    executables.append([positionList[i][1], positionList[i][2], (0,0,255)])
                else:
                    executables.append([positionList[i][1], positionList[i][2], (255,255,255)])
                py.display.update()
    if x > currentHighest:
        currentHighest = x
    return currentHighest


formatter(backdrop)
def deleter(x,y):
    backdrop[x][y] = ' '
    if [x,y] in filled:
        filled.remove([x,y])

def wthHappened():
    if len(filled) != 0:
        high = filled[0][0]
        for i in range(len(filled)):
            if filled[i][0] > high:
                high = filled[i][0]
        return high
# print(filled, "here")
for i in range(1):
    a = random.randint(0,len(potential())-1)
    currentHighest = place(potential()[a][0], potential()[a][1], '2', currentHighest)
for i in range(8):
    a = random.randint(0,len(potential())-1)
    b = random.randint(0,0)
    o = ['1']
    currentHighest = place(potential()[a][0], potential()[a][1], o[b], currentHighest)

q = currentScore()
print(q, "q")
ogCurrentHighest = currentHighest
highestDelta = 0
bestMove = []
# for i in range(len(potential())):
#     x = potential()[i][0]
#     y = potential()[i][1]
#     currentHighest = place(x,y,'1', currentHighest)
#     if currentScore()-q > highestDelta:
#         bestMove = [x,y,'1']
#         highestDelta = currentScore() - q
#     deleter(x,y)
#     currentHighest = ogCurrentHighest
#     currentHighest = place(x, y, '1', currentHighest)
#     if currentScore()-q > highestDelta:
#         bestMove = [x,y,'2']
#         highestDelta = currentScore() - q
#     deleter(x, y)
#     currentHighest = ogCurrentHighest
# print(bestMove)
hit = False

while running:
    for event in py.event.get():
        if event.type == py.QUIT:
            running = False
        elif event.type == py.MOUSEBUTTONDOWN:
            w = py.mouse.get_pressed()
            (a,b) = py.mouse.get_pos()
            for i in range(len(positionList)):
                if (a-positionList[i][1])**2 + (b-positionList[i][2])**2 < minDistance:
                    minDistance = (a-positionList[i][1])**2 + (b-positionList[i][2])**2
                    currentBest = positionList[i][0]
            for i in range(len(indexer)):
                if indexer[i][0] == currentBest:
                    inverse = indexer[i][1]
            if (w[0]):
                currentHighest = place(inverse[0], inverse[1], '1', currentHighest)
            elif(w[-1]):
                currentHighest = place(inverse[0], inverse[1], '2', currentHighest)
            else:
                stop = False
                deleter(inverse[0], inverse[1])
                currentHighest = wthHappened()
                for i in range(len(positionList)):
                    if positionList[i][0] == currentBest:
                        myTuple = [positionList[i][1], positionList[i][2]]

                for i in range(len(executables)):
                    if stop == False:
                        if (executables[i][0] >= myTuple[0]-1 and executables[i][0] <= myTuple[0]+1) and (executables[i][1] >= myTuple[1]-1 and executables[i][1] <= myTuple[1]+1):
                            executables.pop(i)
                            i-=1
                            stop = True
            print("--------------")
            print(f"mosaics present: {mosaicAnalyser()}")
            print(f"current highest row: {currentHighest+1}")
            print(f"current score: {currentScore()} = {math.floor((currentHighest+1)/3)} setlines x 10 + {mosaicCounter()} mosaics x 10 + {int((currentScore()-mosaicCounter()*10-math.floor((currentHighest+1)/3)*10)/3)} pixels x 3")
    py.draw.polygon(screen, (128,128,128), [(50,50), (400,50), (400,570), (50,570)], 0)
    py.draw.polygon(screen, (0,0,0), [(400,570), (350, 570), (400, 570-28.87)], 0)
    py.draw.polygon(screen, (0,0,0), [(50,570), (50, 570-28.87), (100, 570)], 0)
    py.draw.polygon(screen, (60,60,60), [(50, 570 - 108.2625-28.87/2-28.87/8), (50, 570-108.2625-28.87-28.87/8),  (400, 570-108.2625-28.87-28.87/8), (400, 570 - 108.2625-28.87/2-28.87/8)])
    py.draw.polygon(screen, (60,60,60), [(50, 570 - 108.2625 - 137.1325), (50, 570-108.2625-28.87/2 - 137.1325),  (400, 570-108.2625-28.87/2 - 137.1325), (400, 570 - 108.2625 - 137.1325)])
    py.draw.polygon(screen, (60,60,60), [(50, 570 - 108.2625+28.87/2-28.87/8 - 2*137.1325), (50, 570-108.2625-28.87/8 - 2*137.1325),  (400, 570-108.2625-28.87/8 - 2*137.1325), (400, 570 - 108.2625+28.87/2-28.87/8 - 2*137.1325)])

    for i in range(5):
        py.draw.polygon(screen, (0, 0, 0), [(100 + i*50, 570), (125+i*50, 570 - 28.87/2), (150+50*i, 570)], 0)
    place(0, 0, '1', currentHighest)
    for i in range(len(executables)):
        centerer(executables[i][2], executables[i][0], executables[i][1])

    py.display.update()
    minDistance = 100000
    currentBest = 0
    inverse = []
    pixelsPlayed = len(executables)


    # if hit:
    #     x = int(input("x: "))
    #     y = int(input("y: "))
    #     z = input("z: ")
    #     while z not in ["'1'", "'2'"]:
    #         z = input("z: ")
    #     currentHighest = place(x, y, z, currentHighest)
    #     print("h")
    #     py.display.update()
    #     hit = False


# for i in range(40):
#     a = random.randint(0,len(potential())-1)
#     print(potential())
#     b = random.randint(0,1)
#     o = ['1', '2']
#     currentHighest = place(potential()[a][0], potential()[a][1], o[b], currentHighest)
# b = currentScore()
# formatter(backdrop)
# print(blong)
# print(b)
# print(b-blong)
# print(mosaicAnalyser())
